package com.halty.gramalyzerbot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GramalyzerApp {

	public static void main(String[] args) {
		SpringApplication.run(GramalyzerApp.class, args);
	}

}
