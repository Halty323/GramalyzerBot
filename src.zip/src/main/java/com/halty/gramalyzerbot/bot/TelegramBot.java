package com.halty.gramalyzerbot.bot;

import com.halty.gramalyzerbot.bot.handler.RandomHandler;
import com.halty.gramalyzerbot.bot.handler.StartHandler;
import lombok.RequiredArgsConstructor;
import org.jspecify.annotations.NonNull;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.telegram.telegrambots.longpolling.interfaces.LongPollingUpdateConsumer;
import org.telegram.telegrambots.longpolling.starter.SpringLongPollingBot;
import org.telegram.telegrambots.meta.api.objects.Update;

import java.util.List;

@Component
@RequiredArgsConstructor
public class TelegramBot implements SpringLongPollingBot, LongPollingUpdateConsumer {

    private final StartHandler startHandler;
    private final RandomHandler randomHandler;

    @Value("${telegram.bot.token}")
    private String token;

    @Override
    public String getBotToken() {
        return token;
    }

    @Override
    public LongPollingUpdateConsumer getUpdatesConsumer() {
        return this;
    }

    @Override
    public void consume(@NonNull List<Update> updates) {
        for (Update update : updates) {
            handleUpdate(update);
        }
    }

    private void handleUpdate(@NonNull Update update) {
        if (!update.hasMessage()) {
            startHandler.handle(update);
            return;
        }

        if (!update.getMessage().hasText()) {
            startHandler.handle(update);
            return;
        }

        String text = update.getMessage().getText();
        if (text.equals("/start")) {
            startHandler.handle(update);
        } else if (text.equals("/random") || text.equals("Get random number")) {
            randomHandler.handle(update);
        }
    }
}